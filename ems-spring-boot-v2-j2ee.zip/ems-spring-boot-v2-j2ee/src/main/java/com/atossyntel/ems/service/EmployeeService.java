package com.atossyntel.ems.service;

import java.util.List;

import com.atossyntel.ems.model.Employee;

public interface EmployeeService {

	Employee findEmployeeService(int employeeId);

	boolean deleteEmployeeService(int employeeId);

	boolean updateEmployeeService(Employee employee);

	boolean saveEmployeeService(Employee employee);

	List<Employee> findAllEmployeesService();

}
