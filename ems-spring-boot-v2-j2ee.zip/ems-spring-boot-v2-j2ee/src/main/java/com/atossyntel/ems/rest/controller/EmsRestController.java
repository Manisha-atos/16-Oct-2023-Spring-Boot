package com.atossyntel.ems.rest.controller;
import java.util.List;

//import javax.ws.rs.Consumes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.service.EmployeeService;
//
//import io.swagger.annotations.ApiOperation;
//import io.swagger.annotations.ApiResponse;
//import io.swagger.annotations.ApiResponses;

@RequestMapping(value="/employees",produces = {"application/json","application/xml"})
//@RequestMapping(value="/employees")

//json is preferred as parsing xml doument is complex where as in JSOn it is only key value pair
@RestController
public class EmsRestController {


	@Autowired
	private EmployeeService employeeService;

	public EmsRestController() {
		System.out.println
		("######### EmsRestController created########");
	}


	@GetMapping
//	@ApiOperation("Display All Emp;oyees...")
//	@ApiResponse(code=503,message="Invalid Data")
//	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"),@ApiResponse(code = 500, message = "Internal Data"),})

	public List<Employee> getAllEmployees() {
	return employeeService.findAllEmployeesService();
	}
		
	
//	@GetMapping("/{id}")
//	public Employee getEmployee(@PathVariable("id")int id) {
//	return employeeService.findEmployeeService(id);
//	}
	
	@GetMapping("/getID")
	public Employee getEmployee(@RequestParam("id")int id) {
	return employeeService.findEmployeeService(id);
	}
	
	@DeleteMapping("/{id}")
	public List<Employee> deleteEmployee(@PathVariable("id")int id) {
		   employeeService.deleteEmployeeService(id);
		return employeeService.findAllEmployeesService();
	
	}
	

	
	@PutMapping("/{id}")
	public List<Employee> updateEmployee(@PathVariable("id")int id,@RequestBody Employee employee) {
		  employeeService.updateEmployeeService(employee);
		  return employeeService.findAllEmployeesService();
	
	}
	

	@PostMapping
	public List<Employee> addEmployee(@RequestBody Employee employee) {
		  employeeService.saveEmployeeService(employee);
		  return employeeService.findAllEmployeesService();
	
	}
	
	
}
