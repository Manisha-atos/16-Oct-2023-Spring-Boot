package com.atossyntel.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atossyntel.ems.dao.EmployeeDao;
import com.atossyntel.ems.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public Employee findEmployeeService(int employeeId) {
		// TODO Auto-generated method stub

		return employeeDao.findEmployee(employeeId);
	}

	@Override
	public boolean deleteEmployeeService(int employeeId) {

		return employeeDao.deleteEmployee(employeeId);

	}

	@Override
	public boolean updateEmployeeService(Employee employee) {

		return employeeDao.updateEmployee(employee);

	}

	@Override
	public boolean saveEmployeeService(Employee employee) {
		return employeeDao.saveEmployee(employee);
	}

	@Override
	public List<Employee> findAllEmployeesService() {
		return employeeDao.findAllEmployees();
	}

}
