package com.controller;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class helloController {
helloController()
{
	System.out.println("=======HelloConstroller Constructor=======");
}
@RequestMapping("/hello")
public String hello()
{
	System.out.println("#####inside hello Method");
	return "hello";
}

}
