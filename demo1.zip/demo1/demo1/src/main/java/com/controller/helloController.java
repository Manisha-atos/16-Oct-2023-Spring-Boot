package com.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class helloController {
helloController()
{
	System.out.println("=======HelloConstroller Constructor=======");
}
@RequestMapping("/hello")
public String hello()
{
	System.out.println("#####inside hello Method");
	return "hello";
}

@RequestMapping("/today")
public   @ResponseBody String today(){
	return "Today is :"+new Date();
}





}
