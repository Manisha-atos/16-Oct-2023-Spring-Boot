package com.security.config;

import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
@Configuration
//@EnableWebSecurity
public class SecurityConfiguration //extends WebSecurityConfigurerAdapter 
{
	SecurityConfiguration()
	{
		System.out.println("SecurityConfiguration created");
	}
//	@Override
//    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		System.out.println("authontication");
//        auth
//            .inMemoryAuthentication()
//                .withUser("sam").password("{noop}sam").roles("ADMIN").and()
//                .withUser("ram").password("{noop}ram").roles("USER").and()
//                .withUser("ham").password("{noop}ham").roles("USER");
//    }
//	@Override
//    protected void configure(HttpSecurity http) throws Exception {
//        System.out.println("authorization");
//        http.authorizeRequests()
//        .antMatchers("/rest/*").hasRole("ADMIN")
//        .antMatchers("/spring/*").hasRole("USER")
//        .antMatchers("/hello","welcome","/greet/today").hasRole("USER")
//        .anyRequest()//get put post 
//        //.fullyAuthenticated()
//        .permitAll()
//        .and().httpBasic();//basic security
//        http.csrf().disable();//cross site request forgery  unnecessary popups
//        //.and().formLogin();
//    }
}
