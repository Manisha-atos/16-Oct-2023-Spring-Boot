package com.atossyntel.cms.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
//import com.atossyntel.cms.dal.CustomerDao;
import com.atossyntel.cms.model.Customer;
import com.atossyntel.cms.repository.CustomerReository;

@Service
// @Component("customerServiceImpl")
public class CustomerServiceReposioryImpl implements CustomerService {

	// dependency
	@Autowired
	private CustomerReository repository;

	public CustomerServiceReposioryImpl() {
		System.out.println("###### CustomerServiceReposioryImpl created... #########");
	}

	@Override
	public boolean addCustomer(Customer customer) {
		
		// TODO Auto-generated method stub
		
		return repository.save(customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		Customer c = repository.findById(customer.getCustomerId()).get();

		if (c != null) {
			return repository.save(customer) == customer;
		}

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		Customer customer = repository.findById(customerId).get();

		if (customer != null) {
			repository.delete(customer);
			return true;
		}
		
		return false;
		
	}

	@Override
	public Customer findCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return repository.findById(customerId).get();
	}

	@Override
	public List<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
