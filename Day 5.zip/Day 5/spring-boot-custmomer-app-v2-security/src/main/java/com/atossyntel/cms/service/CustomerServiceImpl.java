package com.atossyntel.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

//import com.atossyntel.cms.dal.CustomerDao;
import com.atossyntel.cms.model.Customer;


@Service
//@Component("customerServiceImpl")
public class CustomerServiceImpl{ //implements CustomerService {

//	// dependency
//	@Autowired
//    @Qualifier("customerMapDaoImpl")
//    private CustomerDao customerDao;
//
//	public CustomerServiceImpl() {
//		System.out.println("###### CustomerServiceImpl created... #########");
//	}
//
//	
//	public void setCustomerDao(CustomerDao customerDao) {
//		this.customerDao = customerDao;
//		System.out.println("###### CustomerServiceImpl setCustomerDao method...... #########");
//	}
//
//    
//	public CustomerServiceImpl(CustomerDao customerDao) {
//		this.customerDao = customerDao;
//		System.out.println("###### CustomerServiceImpl param cosnstructor...... #########");
//	}
//
//	@Override
//	public boolean addCustomer(Customer customer) {
//		// TODO Auto-generated method stub
//		return customerDao.addCustomer(customer);
//	}
//
//	@Override
//	public boolean updateCustomer(Customer customer) {
//		// TODO Auto-generated method stub
//		return customerDao.updateCustomer(customer);
//	}
//
//	@Override
//	public boolean deleteCustomer(int customerId) {
//		// TODO Auto-generated method stub
//		return customerDao.deleteCustomer(customerId);
//	}
//
//	@Override
//	public Customer findCustomerById(int customerId) {
//		// TODO Auto-generated method stub
//		return customerDao.findCustomerById(customerId);
//	}
//
//	@Override
//	public List<Customer> findAllCustomers() {
//		// TODO Auto-generated method stub
//		return customerDao.findAllCustomers();
//	}

}
